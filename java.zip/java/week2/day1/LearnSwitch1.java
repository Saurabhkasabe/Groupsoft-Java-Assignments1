package week2.day1;

public class LearnSwitch1 {

	public static void main(String[] args) {
		for (int a=10; a<=20;a++) {
		if (a % 2 == 0){
		System.out.println("a");
	}

}
	}
}
