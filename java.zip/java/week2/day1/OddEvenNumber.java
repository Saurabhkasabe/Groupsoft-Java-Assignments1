package week2.day1;

public class OddEvenNumber {

	public static void main(String[] args) {
		 
		int n=16;
		
	
		if(n%2==1) {
			System.out.println("The given number is odd");
		}else {
			System.out.println("The given number is even");
		}

	}

}
