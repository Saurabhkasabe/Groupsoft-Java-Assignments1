package week2.day3;

public class Concatination {

	public static void main(String[] args) {
		
		String s="Saurabh";
		
		s=s.concat("Kasabe");
		s=s.concat("Pune");
		
		System.out.println(s);

}
}
