package week3.day3;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class AbhiBus_Assignment {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        driver.get("https://www.abhibus.com/");
	    driver.findElement(By.name("(//div[@class='source-input-wrapper col auto'])")).click();

	}

}
