package week1.day2;

public class Bike {
	
	public void bikeName() {
		//System.out.println("Bike Nmae is Honda");
	}

	public static void main(String[] args) {
		//Bike bk = new Bike ();
		//bk.bikeName();
		Car cr = new Car();
		cr.applyBreak();
		cr.soundHorn();
	

	}

}
