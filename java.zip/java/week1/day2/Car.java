package week1.day2;

public class Car {
	
	public void applyBreak() {
		System.out.println("Applied break");
		}
	
	public void soundHorn() {
		System.out.println("Sound Horn");
		
	}
	
	
	

	public static void main(String[] args) {
		Car C = new Car();
		C.applyBreak();
		C.soundHorn();
	}

}
