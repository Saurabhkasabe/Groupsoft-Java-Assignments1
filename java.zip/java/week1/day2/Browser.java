package week1.day2;

public class Browser {

	public static void main(String[] args) {
		Chrome cm = new Chrome ();
		cm.gateName();
		cm.PrintName();

	}

}
