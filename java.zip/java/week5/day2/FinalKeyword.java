package week5.day2;

public class FinalKeyword {

	

		public static final String num="Saurabh";
		
		public static final void subtract() {
			System.out.println("final method");
		}
		
		public static void main(String[] args) {
			System.out.println(num);
		}
	}


