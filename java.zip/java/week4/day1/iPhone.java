package week4.day1;

public class iPhone extends iOS {
	
	public void makeCall () {
		System.out.println("Make Calls");
	}
	
	public void sendSMS() {
		System.out.println("SMS send");
	}

	

}
