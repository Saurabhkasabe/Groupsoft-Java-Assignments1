package week4.day2;

public interface Payments {
	
	
	//public void Phonepay();
		
	
	//public void GooglePay();
	
	
	//public void PayTm();
	
	public void cashOnDelivery();
	
	
	public void upiPayments();
	
	
	public void cardPayments();
	
	public void internetBanking();

}
