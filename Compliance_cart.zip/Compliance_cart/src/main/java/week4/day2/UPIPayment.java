package week4.day2;

public class UPIPayment extends Amazon implements Payments {
	
	
	public void BharatPay() {
		System.out.println("payment done by bharatpay");
	}

	public void Phonepay() {
	System.out.println("Payment done by phonepay");
	}

	public void GooglePay() {
		System.out.println("payment done by google pay");
	}

	public void PayTm() {
	System.out.println("payment done by paytm");
	}

	public void cashOnDelivery() {
		
	}

	public void upiPayments() {
		
	}

	public void cardPayments() {
		
	}

	public void internetBanking() {
		
	}
	
	
	public static void main(String[] args) {
	UPIPayment upi = new UPIPayment();
	Amazon az = new Amazon();
	upi.GooglePay();
	upi.Phonepay();
	upi.PayTm();
	upi.BharatPay();
    az.cardPayments();
    az.cashOnDelivery();
    az.internetBanking();
    az.recordPaymentDetails();
    az.upiPayments();
   
	
	}


}


