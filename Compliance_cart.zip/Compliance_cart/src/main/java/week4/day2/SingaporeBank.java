package week4.day2;

public abstract class SingaporeBank implements Payments {
	
	
	public abstract void recordPaymentDetails();
	

	}


