package week4.day1;

public class iOS {
	public void startApp   () {
		System.out.println("Start the apps");
		
	}
public void increaseVolume () {
	System.out.println("Increased the volume");
	
}
public void shutdown() {
	System.out.println("Shutdown");
	
}

}
