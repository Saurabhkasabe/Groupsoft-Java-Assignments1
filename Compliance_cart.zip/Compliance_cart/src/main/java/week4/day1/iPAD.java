package week4.day1;

public class iPAD extends iOS {
	public void watchMovie() {
		System.out.println(" Wathch the movie");
	}

	
}
