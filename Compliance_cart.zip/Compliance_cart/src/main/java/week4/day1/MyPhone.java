package week4.day1;

public class MyPhone {

	public static void main(String[] args) {
		iPhone IP = new iPhone();
		IP.increaseVolume();
		IP.startApp();
		IP.makeCall();
		IP.sendSMS();
		IP.shutdown();
		
	}

}
