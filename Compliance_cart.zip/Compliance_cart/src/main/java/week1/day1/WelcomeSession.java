package week1.day1;

public class WelcomeSession {
	
	public static void main(String[] args) {
		System.out.println("Welcome to the Java Session");
		
	}

}
