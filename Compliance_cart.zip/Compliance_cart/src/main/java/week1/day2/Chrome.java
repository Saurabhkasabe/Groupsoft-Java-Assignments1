package week1.day2;

public class Chrome {
	
public void gateName() {
	System.out.println("This is google chrome");
	
}

public void PrintName() {
	
	
}
}
