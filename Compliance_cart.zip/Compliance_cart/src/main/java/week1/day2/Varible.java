package week1.day2;

public class Varible {

	public static void main(String[] args) {
		
		float browserVersion = 100.2f;
		String browserName ="Firefox";
		boolean isVisible= true;
		int releaseYear = 1998;
		char browserLogo = 'f';
		
		
		
		System.out.println("The Browswee name is: "+browserName);
		System.out.println(browserLogo  + ": is the logo of the browser");
		System.out.println("The release year is: "  + releaseYear);
		System.out.println("The browser version is: "+ browserVersion);
		System.out.println(isVisible);
		
	}

}
