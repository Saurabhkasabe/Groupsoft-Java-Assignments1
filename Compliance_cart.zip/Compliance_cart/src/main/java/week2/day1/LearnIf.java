package week2.day1;

public class LearnIf {

	public static void main(String[] args) {
		int a = 13;
		if (a%2==0) {
			System.out.println("The number is odd");
			}
		else {
		System.out.println("The number is even");
		}
	}

}
