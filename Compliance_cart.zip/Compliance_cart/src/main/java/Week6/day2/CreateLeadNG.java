package Week6.day2;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class CreateLeadNG extends BaseClass {
	@Test
	public void CreateLead() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		
	}


}
