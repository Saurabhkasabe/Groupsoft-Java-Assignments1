package Week6.day5;


public class BaseClass {

	public static void main(String[] args) {
	
	    	}
	}


