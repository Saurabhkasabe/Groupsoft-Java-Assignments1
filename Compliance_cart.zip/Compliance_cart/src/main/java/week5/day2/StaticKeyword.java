package week5.day2;

public class StaticKeyword extends EmployeeInfo{

	

		public static void main(String[] args) {
			
		
			System.out.println(EmployeeInfo.companyName);
			
			EmployeeInfo.add();
	}

}
