package config;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:config.fr.properties")
public interface ConfigurationManager extends Config{
	
	@Key("implicitWait")
	int getImplicitlyWait();
	
	@Key("username")
	String getUsername();
	
	@Key("password")
	String getPassword();
	
	@Key("welcome")
	String getWelcomeMsg();
	
	@Key("leadslink")
	String getLeadsLink();
	
	@Key("createLeadLink")
	String getCreateLeadLink();

}
