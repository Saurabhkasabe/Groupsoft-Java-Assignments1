package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecifcMethods;
import config.Configuration;

public class WelcomePage extends ProjectSpecifcMethods{
	
	public WelcomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public WelcomePage verifyHomePage() {
		String welcomeMsg = Configuration.configuration().getWelcomeMsg();
		String text = driver.findElement(By.xpath(welcomeMsg)).getText();
		System.out.println(text);
		
		if (text.contains(text)) {
			System.out.println("WelcomePage is displayed");
		}
		else {
			System.out.println("WelcomePage is not displayed");
		}
		return this;
	}
	
	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage(driver);

	}

}
