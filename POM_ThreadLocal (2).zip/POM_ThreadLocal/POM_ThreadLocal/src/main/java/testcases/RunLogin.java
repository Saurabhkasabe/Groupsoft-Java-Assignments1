package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.LoginPage;
import base.ProjectSpecificMethod;

public class RunLogin extends ProjectSpecificMethod{
	@BeforeTest
	public void setvalues(){
		fileName="login";
	}
	
	@Test(dataProvider="fetchData")
	public void runLogin(String uname,String pWord) {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uname)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFALink();
	}
}
