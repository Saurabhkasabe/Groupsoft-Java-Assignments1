package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.LoginPage;
import base.ProjectSpecificMethod;

public class RunCreateLead extends ProjectSpecificMethod{
	
	@BeforeTest
	public void setValues() {
		fileName="createLead";
	}
	
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pWord, String cName,String fName, String lName) {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage()
		.clickCRMSFALink()
		.clickLeadsLink()
		.clickCreateLeadsLink()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLeadButton()
		.verifyViewLeads(cName);	
	}

}
