package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{
	
	public LoginPage enterUsername(String uname) {
		getDriver().findElement(By.id("username")).sendKeys(uname);
		return this;
	}
	public LoginPage enterPassword(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);;
		return this;
	}
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
	
}
