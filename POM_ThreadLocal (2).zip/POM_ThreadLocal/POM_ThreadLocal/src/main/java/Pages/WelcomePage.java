package Pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{
	
	public WelcomePage verifyHomePage() {
		
		String text=getDriver().findElement(By.tagName("h2")).getText();
		if(text.contains("Welcome")) {
			System.out.println("Welcome page is displayed");
			}
		else {
			System.out.println("Welcome page is not displayed");
		}
		return this;
	    }
		public MyHomePage clickCRMSFALink() {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
		     return new MyHomePage();
		}
		 
}
