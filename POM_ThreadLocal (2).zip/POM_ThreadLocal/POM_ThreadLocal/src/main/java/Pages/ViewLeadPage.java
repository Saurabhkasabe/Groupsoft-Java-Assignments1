package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod {
//	public ViewLeadPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	public ViewLeadPage verifyViewLeads(String cName) {
		String text= getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		if(text.contains("Groupsoft")) {
			System.out.println("Lead created ");
		}
		else {
			System.out.println("Lead is not created");
		}
		return this;
	}

}
