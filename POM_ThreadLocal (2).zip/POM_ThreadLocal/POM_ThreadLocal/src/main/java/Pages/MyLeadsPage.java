package Pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class MyLeadsPage extends ProjectSpecificMethod{
	
	public CreateLeadPage clickCreateLeadsLink() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
}
